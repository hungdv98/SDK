#!/usr/bin/env python3

import json
import re
import sys
# import inspect  # DEBUG
# import logging  # DEBUG
# import http.client # DEBUG
import time

import requests

# http.client.HTTPConnection.debuglevel = 1  # DEBUG

# logging.basicConfig()  # DEBUG
# logging.getLogger().setLevel(logging.DEBUG)  # DEBUG
# requests_log = logging.getLogger("requests.packages.urllib3")  # DEBUG
# requests_log.setLevel(logging.DEBUG)  # DEBUG
# requests_log.propagate = True  # DEBUG

class intelx:

    API_ROOT = 'https://2.intelx.io'
    API_RATE_LIMIT = 1
    TIMEOUT = 30

    # The API key must be always supplied
    def __init__(self, api_key, base_url: str | None = None, user_agent='IX-Python/0.8', proxies=None, verify=True):
        """
        Initialize API by setting the API key.
        """
        self.API_KEY = api_key
        if base_url is not None:
            self.API_ROOT = base_url
        else:
            self.API_ROOT = type(self).API_ROOT
        self.USER_AGENT = user_agent
        self.API_RATE_LIMIT = type(self).API_RATE_LIMIT
        self.HEADERS = {'X-Key': self.API_KEY, 'User-Agent': self.USER_AGENT}
        self.PROXIES = proxies
        self.VERIFY = verify

    def _get(self, url, params=None, headers=None, proxies=None, verify=None, timeout=None, **kwargs ):
        if headers is None:
            headers = self.HEADERS
        if proxies is None:
            proxies = self.PROXIES
        if verify is None:
            verify = self.VERIFY
        if timeout is None:
            timeout = self.TIMEOUT
        if not url.startswith(("https://", "http://")):
            url = self.API_ROOT + url

        return requests.get(url, params=params, headers=headers, proxies=proxies, verify=verify, timeout=timeout, **kwargs )

    def _post(self, url, data=None, json=None, headers=None, proxies=None, verify=None, timeout=None, **kwargs ):
        if headers is None:
            headers = self.HEADERS
        if proxies is None:
            proxies = self.PROXIES
        if verify is None:
            verify = self.VERIFY
        if timeout is None:
            timeout = self.TIMEOUT
        if not url.startswith(("https://", "http://")):
            url = self.API_ROOT + url

        return requests.post(url, data=data, json=json, headers=headers, proxies=proxies, verify=verify, timeout=timeout, **kwargs, )

    def get_error(self, code):
        """
        Get error string by respective HTTP response code.
        """
        if code == 200:
            return "200 | Success"
        if code == 204:
            return "204 | No Content"
        if code == 400:
            return "400 | Bad Request"
        if code == 401:
            return "401 | Unauthorized"
        if code == 402:
            return "402 | Payment required."
        if code == 404:
            return "404 | Not Found"

        """
        Get error string by respective intelx.io status code.
        """
        if code == 1:
            return "1 | Invalid term"

    def cleanup_treeview(self, treeview):
        """
        Cleans up treeview output from the API.
        """
        lines = []
        for line in treeview.split("\r\n"):
            if '<a href' not in line:
                lines.append(line)
        return lines

    def GET_CAPABILITIES(self):
        """
        Return a JSON object with the current user's API capabilities
        """
        time.sleep(self.API_RATE_LIMIT)
        r = self._get("/authenticate/info")
        if r.status_code == 200:        
            return r.json()
        else:
            return r.status_code

    def FILE_PREVIEW(self, ctype, mediatype, format, sid, bucket='', e=0, lines=8):
        """
        Show a preview of a file's contents based on its storageid (sid).
        format option:
        - 0: Text
        - 1: Picture
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "c": ctype,
            "m": mediatype,
            "f": format,
            "sid": sid,
            "b": bucket,
            "e": e,
            "l": lines,
            "k": self.API_KEY,
        }
        r = self._get("/file/preview", params=p)
        return r.text

    def FILE_VIEW(self, ctype, mediatype, sid, bucket='', escape=0):
        """
        Show a file's contents based on its storageid (sid), convert to text where necessary.

        format option:
        - 0: textview of content
        - 1: hex view of content
        - 2: auto detect hex view or text view
        - 3: picture view
        - 4: not supported
        - 5: html inline view (sanitized)
        - 6: text view of pdf
        - 7: text view of html
        - 8: text view of word file
        """
        format = 0
        if(mediatype == 23 or mediatype == 9):    # HTML
            format = 7
        elif(mediatype == 15):                # PDF
            format = 6
        elif(mediatype == 16):                # Word
            format = 8
        elif(mediatype == 18):                # PowerPoint
            format = 10
        elif(mediatype == 25):                # Ebook
            format = 11
        elif(mediatype == 17):                # Excel
            format = 9
        elif(ctype == 1):                        # Text
            format = 0
        else:
            format = 1
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "f": format,
            "storageid": sid,
            "bucket": bucket,
            "escape": escape,
            "k": self.API_KEY,
        }
        r = self._get("/file/view", params=p)
        return r.text

    def FILE_READ(self, id, type=0, bucket="", filename=""):
        """
        Read a file's raw contents. Use this for direct data download.

        id option:
        - Specifies the item's system ID to read.

        type option:
        - Specifies content disposition or not.
        - 0: No content disposition. Returns raw binary file.
        - 1: Content disposition. May fix line endings to CR LF for text files.

        bucket option:
        - Bucket is required.

        name option:
        - Specify the name to save the file as (e.g document.pdf).
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "type": type,
            "systemid": id,
            "bucket": bucket,
        }
        r = self._get("/file/read", params=p, stream=True)
        with open(f"{filename}", "wb") as f:
            f.write(r.content)
            f.close()
        return True

    def FILE_TREE_VIEW(self, sid):
        """
        Show a treeview of an item that has multiple files/folders
        """
        time.sleep(self.API_RATE_LIMIT)
        try:
            p = {
                "f": 12,
                "storageid": sid,
                "k": self.API_KEY,
            }
            r = self._get("/file/view", params=p, timeout=5)
            if "Could not generate" in r.text:
                return False
            return r.text
        except:
            return False

    def INTEL_SEARCH(self, term, maxresults=100, buckets=[], timeout=5, datefrom="", dateto="", sort=4, media=0, terminate=[]):
        """
        Initialize an intelligent search and return the ID of the task/search for further processing.

        maxresults option:
        - Tells how many results to query maximum per bucket.
        - Example: maxresults=100

        buckets option:
        - Specify the buckets to search
        - Example: buckets=[]
        - Example: buckets=['pastes', 'darknet.i2p']

        timeout option:
        - Set a timeout value for the search.
        - Example: timeout=5

        datefrom option:
        - Set a starting date to begin the search from.
        - Example: 2020-01-01 00:00:00
        - Example: 2020-01-01 12:00:00

        dateto option:
        - Set an ending date to finish the search from.
        - Example: 2020-02-02 23:59:59
        - Example: 2020-02-02 00:00:00

        sort option:
        - Define the way to sort search results.
        - 0: No sorting.
        - 1: X-Score ASC. Least relevant items first.
        - 2: X-Score DESC. Most relevant items first.
        - 3: Date ASC. Oldest items first.
        - 4: Date DESC. Newest items first.

        media option:
        - Define the type of media to search for.
        - 0: Not set. (All media types)
        - 1: Paste document
        - 2: Paste User
        - 3: Forum
        - 4: Forum Board
        - 5: Forum Thread
        - 6: Forum Post
        - 7: Forum User
        - 8: Screenshot of a Website
        - 9: HTML copy of a website.
        - 10: Invalid, do not use.
        - 11: Invalid, do not use.
        - 12: Invalid, do not use.
        - 13: Tweet
        - 14: URL, high-level item having HTML copies as linked sub-items
        - 15: PDF document
        - 16: Word document
        - 17: Excel document
        - 18: Powerpoint document
        - 19: Picture
        - 20: Audio file
        - 21: Video file
        - 22: Container files including ZIP, RAR, TAR and others
        - 23: HTML file
        - 24: Text file

        The term must be a strong selector. These selector types are currently supported:
        - Email address
        - Domain, including wildcards like *.example.com
        - URL
        - IPv4 & IPv6
        - CIDRv4 & CIDRv6
        - Phone Number
        - Bitcoin Address
        - MAC Address
        - IPFS Hash
        - UUID
        - Storage ID
        - System ID
        - Simhash
        - Credit card number
        - IBAN

        Soft selectors (generic terms) are not supported!
        """
        p = {
            "term": term,
            "buckets": buckets,
            "lookuplevel": 0,
            "maxresults": maxresults,
            "timeout": timeout,
            "datefrom": datefrom,
            "dateto": dateto,
            "sort": sort,
            "media": media,
            "terminate": terminate
        }
        time.sleep(self.API_RATE_LIMIT)
        r = self._post('/intelligent/search', json=p)
        if r.status_code == 200:
            if r.json()['status'] == 1:
                return r.json()['status']
            return r.json()['id']
        else:
            return r.status_code

    def INTEL_SEARCH_RESULT(self, id, limit):
        """
        Return results from an initialized search based on its ID

        status (results status):
        - 0: Success with results.
        - 1: No more results available.
        - 2: Search ID not found.
        - 3: No results yet, but keep trying.

        type (low-level data type of result):
        - 0: Binary/unspecified
        - 1: Plain text
        - 2: Picture
        - 3: Video
        - 4: Audio
        - 5: Document file
        - 6: Executable file
        - 7: Container
        - 1001: User
        - 1002: Leak
        - 1004: URL
        - 1005: Forum

        media (high-level data type):
        - 0: Invalid
        - 1: Paste document
        - 2: Paste user
        - 3: Forum
        - 4: Forum Board
        - 5: Forum Thread
        - 6: Forum Post
        - 7: Forum User
        - 8: Screenshot of a website
        - 9: HTML copy of a website
        - 10: Invalid, do not use.
        - 11: Invalid, do not use.
        - 12: Invalid, do not use.
        - 13: Tweet
        - 14: URL, high-level item having HTML copies as linked sub-items.
        - 15: PDF Document
        - 16: Word document
        - 17: Excel document
        - 18: Powerpoint document
        - 19: Picture
        - 20: Audio file
        - 21: Video file
        - 22: Container files
        - 23: HTML file
        - 24: Text file

        added:
        - When the item was indexed.

        date:
        - The date of the original record if available.

        name:
        - Name of title

        description:
        - Typically not used

        xscore:
        - Relevancy score, between 0-100

        simhash:
        - Similarity hash, depending on the content type

        bucket:
        - The bucket in which the result was found.

        keyvalues:
        - Not used

        tags:
        - Additional information on the item

        relations:
        - Identifiers of related items

        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "id": id,
            "limit": limit,
        }
        r = self._get('/intelligent/search/result', params=p)
        if(r.status_code == 200):
            return r.json()
        else:
            return r.status_code

    def INTEL_TERMINATE_SEARCH(self, uuid):
        """
        Terminate a previously initialized search based on its UUID.
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "id": uuid,
        }
        r = self._get('/intelligent/search/terminate', params=p)
        if(r.status_code == 200):
            return True
        else:
            return r.status_code

    def PHONEBOOK_SEARCH(self, term, maxresults=100, buckets=[], timeout=5, datefrom="", dateto="", sort=4, media=0, terminate=[], target=0):
        """
        Initialize a phonebook search and return the ID of the task/search for further processing
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "term": term,
            "buckets": buckets,
            "lookuplevel": 0,
            "maxresults": maxresults,
            "timeout": timeout,
            "datefrom": datefrom,
            "dateto": dateto,
            "sort": sort,
            "media": media,
            "terminate": terminate,
            "target": target
        }
        r = self._post('/phonebook/search', json=p)
        if r.status_code == 200:
            return r.json()['id']
        else:
            return r.status_code

    def PHONEBOOK_SEARCH_RESULT(self, id, limit=1000, offset=-1):
        """
        Fetch results from a phonebook search based on ID.
        offset:
        - Do not use. If omitted (default), each call will get the next available results.
        ___________________________________________
        RETURN VALUES
        status (results status):
        - 0: Success with results.
        - 1: No more results available.
        - 2: Search ID not found.
        - 3: No results yet, but keep trying.
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "id": id,
            "limit": limit,
            "offset": offset,
        }
        r = self._get('/phonebook/search/result', params=p)
        if(r.status_code == 200):
            return r.json()
        else:
            return r.status_code

    def INTEL_EXPORT(self, id, f=1, l=1000):
        """
        Export all file from search. Use this for direct data download All file in one time.
        id - Specifies search ID.
        f -	Export format (0 csv, 1 zip).
        l -	Result limit. Defaults to 1000. (opitional)
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "id": id,
            "f": f,
            "l": l,
        }
        r = self._get("/intelligent/search/export", params=p) 
        if r.status_code == 200:
            cd = r.headers.get("Content-Disposition", "")
            match = re.search(r'filename="?([^"]+)"?', cd)
            if match:
                filename = match.group(1)

            if len(str(filename)) == 0:
                return False

            with open(filename, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:  # filter out keep-alive chunks
                        f.write(chunk)
            return True
        else:
            return r.status_code

    def query_results(self, id, limit):
        """
        Query the results from an intelligent search.
        Meant for usage within loops.
        """
        results = self.INTEL_SEARCH_RESULT(id, limit)
        return results

    def exportfromsearch(self, term, export_format=0, maxresults=100, buckets=[], timeout=5, datefrom="", dateto="", sort=4, media=0, terminate=[], filename=None):
        search_id = self.INTEL_SEARCH(term, maxresults, buckets, timeout, datefrom, dateto, sort, media, terminate)

        if(len(str(search_id)) <= 3):
            print(f"[!] intelx.INTEL_SEARCH() Received {self.get_error(search_id)}")
            sys.exit()
        r = self.INTEL_EXPORT(search_id, export_format, maxresults)
        return r

    def query_pb_results(self, id, limit):
        """
        Query the results from a phonebook search.
        Meant for usage within loops.
        """
        results = self.PHONEBOOK_SEARCH_RESULT(id, limit)
        return results

    def treeview(self, id, bucket):
        """
        Fetch Tree View for an item. Result is JSON array of items, input is the storage ID of the tree view data.
          a. Historical copies of websites. Use the storage ID from the field "historyfile" in the search result.
          b. List of indexed sub-pages for a given website. Use the storage ID from the field "indexfile" in the search result.
        """
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "f": 13,
            "storageid": id,
            "bucket": bucket,
        }
        r = self._get('/file/view', params=p)

        if(r.status_code == 200):
            return r.json()
        else:
            return r.status_code


    def search(self, term, maxresults=100, buckets=[], timeout=5, datefrom="", dateto="", sort=4, media=0, terminate=[]):
        """
        Conduct a simple search based on a search term.
        Other arguments have default values set, however they can be overridden to complete an advanced search.

        maxresults option:
        - Tells how many results to query maximum per bucket.
        - Example: maxresults=100

        buckets option:
        - Specify the buckets to search
        - Example: buckets=[]
        - Example: buckets=['pastes', 'darknet.i2p']

        timeout option:
        - Set a timeout value for the search.
        - Example: timeout=5

        datefrom option:
        - Set a starting date to begin the search from.
        - Example: 2020-01-01 00:00:00
        - Example: 2020-01-01 12:00:00

        dateto option:
        - Set an ending date to finish the search from.
        - Example: 2020-02-02 23:59:59
        - Example: 2020-02-02 00:00:00

        sort option:
        - Define the way to sort search results.
        - 0: No sorting.
        - 1: X-Score ASC. Least relevant items first.
        - 2: X-Score DESC. Most relevant items first.
        - 3: Date ASC. Oldest items first.
        - 4: Date DESC. Newest items first.

        media option:
        - Define the type of media to search for.
        - 0: Not set. (All media types)
        - 1: Paste document
        - 2: Paste User
        - 3: Forum
        - 4: Forum Board
        - 5: Forum Thread
        - 6: Forum Post
        - 7: Forum User
        - 8: Screenshot of a Website
        - 9: HTML copy of a website.
        - 10: Invalid, do not use.
        - 11: Invalid, do not use.
        - 12: Invalid, do not use.
        - 13: Tweet
        - 14: URL, high-level item having HTML copies as linked sub-items
        - 15: PDF document
        - 16: Word document
        - 17: Excel document
        - 18: Powerpoint document
        - 19: Picture
        - 20: Audio file
        - 21: Video file
        - 22: Container files including ZIP, RAR, TAR and others
        - 23: HTML file
        - 24: Text file

        The term must be a strong selector. These selector types are currently supported:
        - Email address
        - Domain, including wildcards like *.example.com
        - URL
        - IPv4 & IPv6
        - CIDRv4 & CIDRv6
        - Phone Number
        - Bitcoin Address
        - MAC Address
        - IPFS Hash
        - UUID
        - Storage ID
        - System ID
        - Simhash
        - Credit card number
        - IBAN

        Soft selectors (generic terms) are not supported!

        """
        results = []
        done = False
        search_id = self.INTEL_SEARCH(term, maxresults, buckets, timeout, datefrom, dateto, sort, media, terminate)
        if(len(str(search_id)) <= 3):
            print(f"[!] intelx.INTEL_SEARCH() Received {self.get_error(search_id)}")
            sys.exit()
        while done == False:
            time.sleep(1)  # lets give the backend a chance to aggregate our data
            r = self.query_results(search_id, maxresults)
            for a in r['records']:
                results.append(a)
            maxresults -= len(r['records'])
            if(r['status'] == 1 or r['status'] == 2 or maxresults <= 0):
                if(maxresults <= 0):
                    self.INTEL_TERMINATE_SEARCH(search_id)
                done = True
        return {'records': results}

    def phonebooksearch(self, term, maxresults=1000, buckets=[], timeout=5, datefrom="", dateto="", sort=4, media=0, terminate=[], target=0):
        """
        Conduct a phonebook search based on a search term.
        Other arguments have default values set, however they can be overridden to complete an advanced search.
        """
        results = []
        done = False
        search_id = self.PHONEBOOK_SEARCH(term, maxresults, buckets, timeout, datefrom, dateto, sort, media, terminate, target)
        if(len(str(search_id)) <= 3):
            print(f"[!] intelx.PHONEBOOK_SEARCH() Received {self.get_error(search_id)}")
            sys.exit()
        while done == False:
            time.sleep(1)  # lets give the backend a chance to aggregate our data
            r = self.query_pb_results(search_id, maxresults)
            results.append(r)
            maxresults -= len(r['selectors'])
            if(r['status'] == 1 or r['status'] == 2 or maxresults <= 0):
                if(maxresults <= 0):
                    self.INTEL_TERMINATE_SEARCH(search_id)
                done = True
        return results

    def stats(self, search):
        stats = {}
        for record in search['records']:
            if record['bucket'] not in stats:
                stats[record['bucket']] = 1
            else:
                stats[record['bucket']] += 1
        return json.dumps(stats)

    def selectors(self, document):
        time.sleep(self.API_RATE_LIMIT)
        p = {
            "id": document,
            "k": self.API_KEY,
        }
        r = self._get('/item/selector/list/human', params=p)
        return r.json()['selectors']
